"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent } from "@/components/ui/card"
import OrderSummary from "@/components/order-summary"
import ProductList from "@/components/product-list"
import CategoryTabs from "@/components/category-tabs"
import type { Product, OrderItem } from "@/types"

export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [orderItems, setOrderItems] = useState<OrderItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeCategory, setActiveCategory] = useState("Comida")

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const supabase = createClient()
      const { data, error } = await supabase.from("products").select("*").order("category").order("name")

      if (error) throw error
      setProducts(data || [])
      // Set initial category from first product
      if (data && data.length > 0) {
        setActiveCategory(data[0].category || "Comida")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error loading products")
    } finally {
      setLoading(false)
    }
  }

  const filteredProducts = products.filter((p) => p.category === activeCategory)
  const categories = Array.from(new Set(products.map((p) => p.category))).sort()

  const addProductToOrder = (product: Product) => {
    setOrderItems((prev) => {
      const existing = prev.find((item) => item.product_id === product.id)
      if (existing) {
        return prev.map((item) => (item.product_id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
      }
      return [
        ...prev,
        {
          id: Math.random().toString(),
          product_id: product.id,
          product_name: product.name,
          price: Number(product.price),
          quantity: 1,
        },
      ]
    })
  }

  const updateQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      setOrderItems((prev) => prev.filter((item) => item.id !== itemId))
    } else {
      setOrderItems((prev) => prev.map((item) => (item.id === itemId ? { ...item, quantity } : item)))
    }
  }

  const removeItem = (itemId: string) => {
    setOrderItems((prev) => prev.filter((item) => item.id !== itemId))
  }

  const clearOrder = () => {
    setOrderItems([])
  }

  const handlePrint = async () => {
    if (orderItems.length === 0) {
      alert("No items in order to print")
      return
    }

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0)

    const itemsHTML = orderItems
      .map(
        (item) =>
          `<tr>
        <td style="padding: 8px; border-bottom: 1px solid #8B6F47;">${item.product_name}</td>
        <td style="padding: 8px; border-bottom: 1px solid #8B6F47; text-align: center;">${item.quantity}</td>
        <td style="padding: 8px; border-bottom: 1px solid #8B6F47; text-align: right;">$${item.price.toFixed(2)}</td>
        <td style="padding: 8px; border-bottom: 1px solid #8B6F47; text-align: right;">$${(item.price * item.quantity).toFixed(2)}</td>
      </tr>`,
      )
      .join("")

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Pedido - Parada Caribe</title>
        <style>
          body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            max-width: 400px; 
            margin: 0; 
            padding: 20px; 
            background-color: #FFF8DC;
            color: #3D2817;
          }
          .header { 
            text-align: center; 
            margin-bottom: 30px; 
            border-bottom: 3px solid #8B6F47; 
            padding-bottom: 20px;
            background-color: #D2B48C;
            padding: 15px;
            border-radius: 8px;
          }
          .title { 
            font-size: 28px; 
            font-weight: bold; 
            margin-bottom: 5px;
            color: #3D2817;
          }
          .subtitle {
            font-size: 14px;
            color: #5C4033;
            margin-bottom: 10px;
          }
          .date { 
            font-size: 12px; 
            color: #5C4033;
            font-weight: 500;
          }
          table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 20px; 
            margin-top: 20px;
          }
          th { 
            background-color: #D2B48C; 
            padding: 10px; 
            text-align: left; 
            border-bottom: 2px solid #8B6F47;
            font-weight: bold;
            color: #3D2817;
          }
          td {
            padding: 8px;
            color: #3D2817;
          }
          .summary { 
            border-top: 2px solid #8B6F47; 
            padding-top: 15px; 
            background-color: #FFF8DC;
            border-radius: 8px;
            padding: 15px;
          }
          .total { 
            font-size: 20px; 
            font-weight: bold; 
            text-align: right; 
            margin-top: 15px;
            color: #3D2817;
            background-color: #D2B48C;
            padding: 12px;
            border-radius: 6px;
          }
          .footer { 
            text-align: center; 
            margin-top: 30px; 
            font-size: 13px; 
            color: #5C4033;
            font-weight: 500;
          }
          .copy-marker {
            text-align: center;
            font-size: 10px;
            color: #8B6F47;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px dashed #8B6F47;
          }
          @media print { 
            body { margin: 0; padding: 10px; background-color: white; }
            .copy-marker { page-break-after: always; }
          }
        </style>
      </head>
      <body>
        <div style="page-break-inside: avoid;">
          <div class="header">
            <div class="title">🏝️ PARADA CARIBE</div>
            <div class="subtitle">Pedido de Cliente</div>
            <div class="date">${new Date().toLocaleString("es-ES")}</div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHTML}
            </tbody>
          </table>

          <div class="summary">
            <div class="total">TOTAL: $${total.toFixed(2)}</div>
          </div>

          <div class="footer">
            <p>¡Gracias por su compra! 🌴</p>
          </div>
        </div>

        <div class="copy-marker">─────────────────────────────</div>

        <div style="page-break-inside: avoid; margin-top: 40px;">
          <div class="header">
            <div class="title">🏝️ PARADA CARIBE</div>
            <div class="subtitle">Copia para Negocio</div>
            <div class="date">${new Date().toLocaleString("es-ES")}</div>
          </div>
          
          <table>
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHTML}
            </tbody>
          </table>

          <div class="summary">
            <div class="total">TOTAL: $${total.toFixed(2)}</div>
          </div>

          <div class="footer">
            <p>Copia del Negocio</p>
          </div>
        </div>
      </body>
      </html>
    `

    printWindow.document.write(htmlContent)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <main className="min-h-screen bg-background p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header with Caribbean Vibes */}
        <div className="mb-8">
          <div className="mb-4">
            <h1 className="text-5xl md:text-6xl font-black text-primary">🏝️ PARADA CARIBE</h1>
            <p className="text-xl font-semibold text-secondary mt-2">Sistema de Pedidos y Vouchers</p>
          </div>
        </div>

        {/* Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Products Section */}
          <div className="lg:col-span-2">
            {/* Category Tabs */}
            {!loading && !error && categories.length > 0 && (
              <CategoryTabs
                categories={categories}
                activeCategory={activeCategory}
                onCategoryChange={setActiveCategory}
              />
            )}

            {loading ? (
              <Card className="bg-surface border-2 border-primary border-opacity-20">
                <CardContent className="pt-6">
                  <p className="text-center text-muted-foreground font-semibold">Cargando productos...</p>
                </CardContent>
              </Card>
            ) : error ? (
              <Card className="bg-surface border-2 border-red-500 border-opacity-30">
                <CardContent className="pt-6">
                  <p className="text-center text-red-600 font-semibold">{error}</p>
                </CardContent>
              </Card>
            ) : (
              <ProductList products={filteredProducts} onAddProduct={addProductToOrder} />
            )}
          </div>

          {/* Order Summary Section */}
          <div className="lg:col-span-1">
            <OrderSummary
              items={orderItems}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeItem}
              onClearOrder={clearOrder}
              onPrint={handlePrint}
            />
          </div>
        </div>
      </div>
    </main>
  )
}
